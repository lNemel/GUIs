/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package starframe;

/**
 *
 * @author Elva Mariana
 */
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;

public class StarFrame extends JFrame{
    private JLabel myLabel;
    /**
     * @param args the command line arguments
     */
    public StarFrame(){
        setTitle("Hola Mundo JFrame");
        setSize(300,200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout (new FlowLayout());
        
        myLabel = new JLabel ("Hola Mundo");
        add (myLabel);
        setVisible (true);
    }
    public static void main(String[] args) {
        new StarFrame ();
    }
}
